# LAN Remote Access

A Python desktop application scaffold for consent-based remote assistance on a local area network (LAN).

## Project status

Foundation stage only. This scaffold does not open network ports, accept remote commands, transfer files, or run in the background.

## Requirements

- Python 3.10 or newer
- Tkinter (usually included with standard Python distributions)

No third-party packages are required for this foundation stage.

## Project layout

```text
LAN-Remote-Access/
├── host/
│   ├── __init__.py
│   ├── host.py
│   └── approval.py
├── client/
│   ├── __init__.py
│   └── client.py
├── security/
│   ├── __init__.py
│   ├── authentication.py
│   └── encryption.py
├── interface/
│   ├── __init__.py
│   └── main.py
├── logs/
│   └── .gitkeep
├── .gitignore
└── README.md
```

## Run the placeholders

From this directory:

```bash
python -m host.host
python -m client.client
python -m interface.main
```

Each command prints a placeholder status only. No network activity occurs.

## Safety design

- The host owner must explicitly approve every incoming session.
- The application will use authenticated, encrypted LAN communication.
- Remote actions will be limited to clearly defined, user-approved functions.
- No stealth, persistence, arbitrary remote shell, or unattended access is part of this project.
