"""Desktop interface components."""
