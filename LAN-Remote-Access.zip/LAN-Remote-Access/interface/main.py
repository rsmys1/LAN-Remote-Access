"""Placeholder for the Tkinter desktop interface."""


def main() -> None:
    """Launch the desktop interface once the UI module is implemented."""
    print("LAN Remote Access — UI placeholder")


if __name__ == "__main__":
    main()
