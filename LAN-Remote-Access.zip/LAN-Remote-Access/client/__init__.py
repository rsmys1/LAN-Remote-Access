"""Client-side components for the LAN Remote Access application."""
