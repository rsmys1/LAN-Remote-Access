"""Entry point placeholder for the authorized LAN client."""


def main() -> None:
    """Start the client application (implemented in a later module)."""
    print("LAN Remote Access — Client placeholder")
    print("No connection is attempted in this foundation stage.")


if __name__ == "__main__":
    main()
