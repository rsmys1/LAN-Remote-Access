"""Entry point placeholder for the authorized LAN host."""


def main() -> None:
    """Start the host application (implemented in a later module)."""
    print("LAN Remote Access — Host placeholder")
    print("No network listener is started in this foundation stage.")


if __name__ == "__main__":
    main()
