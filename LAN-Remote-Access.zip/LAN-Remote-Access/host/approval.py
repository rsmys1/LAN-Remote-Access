"""Placeholder for explicit host-owner session approval."""


def request_session_approval() -> bool:
    """Return an approval decision once the consent flow is implemented."""
    raise NotImplementedError("Session approval will be implemented in a later module.")
