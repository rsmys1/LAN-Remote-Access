"""Security components for authentication and encrypted transport."""
